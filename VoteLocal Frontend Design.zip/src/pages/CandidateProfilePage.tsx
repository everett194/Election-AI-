import { useState } from 'react'
import { useNav } from '../context/nav'
import { CANDIDATES } from '../data/placeholder'
import { EvidenceBadge, ConfidenceIndicator, PartyLabel, IssueTag, PolicyScaleBar } from '../components/Badges'
import { Avatar } from '../components/Cards'
import { Alert, Disclaimer, SourceCitation, PlaceholderBadge, Modal, Tooltip } from '../components/ui'
import type { Source } from '../types'

// ─── Source panel ─────────────────────────────────────────────────────────────

function SourcePanel({ sources, isOpen, onToggle }: { sources: Source[]; isOpen: boolean; onToggle: () => void }) {
  if (sources.length === 0) return null
  return (
    <div className="mt-2.5">
      <button
        onClick={onToggle}
        className="flex items-center gap-1.5 text-xs text-civic hover:text-civic-light font-medium transition-colors"
      >
        <svg viewBox="0 0 14 14" fill="currentColor" className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-90' : ''}`}>
          <path fillRule="evenodd" clipRule="evenodd" d="M4.22 5.72a.5.5 0 01.7 0L7 7.8l2.08-2.08a.5.5 0 01.7.7l-2.43 2.43a.5.5 0 01-.7 0L4.22 6.42a.5.5 0 010-.7z"/>
        </svg>
        {isOpen ? 'Hide' : 'Show'} {sources.length} source{sources.length > 1 ? 's' : ''}
      </button>

      {isOpen && (
        <div className="mt-2 pl-3 border-l-2 border-border space-y-3">
          {sources.map((source, i) => (
            <div key={i} className="space-y-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <EvidenceBadge type={source.type} size="xs" withTooltip />
                <span className="text-[11px] font-medium text-navy/70">{source.outlet}</span>
                <span className="text-[11px] text-muted">·  {source.date}</span>
              </div>
              <p className="text-xs text-navy/50 italic pl-1">"{source.title}"</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Public statement card ───────────────────────────────────────────────────

interface PublicStatement {
  quote: string
  context: string
  date: string
  outlet: string
}

const SAMPLE_STATEMENTS: PublicStatement[] = [
  {
    quote: "We can't solve District 3's affordability crisis without requiring developers to contribute affordable units. Voluntary programs have not worked.",
    context: 'Candidate forum on housing policy',
    date: 'March 12, 2025',
    outlet: 'Riverside Press-Enterprise',
  },
  {
    quote: "Mental health crises require mental health professionals, not just law enforcement. A co-responder model is commonsense policy that other cities have proven works.",
    context: 'Public safety town hall, Eastside Community Center',
    date: 'April 8, 2025',
    outlet: 'District 3 Town Hall (video transcript)',
  },
  {
    quote: "Our transit infrastructure is decades behind. Converting one arterial lane on Magnolia to dedicated bus rapid transit would cut commute times in half for thousands of residents.",
    context: 'Transit First Riverside coalition endorsement remarks',
    date: 'February 20, 2025',
    outlet: 'Transit First Riverside',
  },
]

export default function CandidateProfilePage() {
  const { navigate } = useNav()
  const candidate = CANDIDATES['jordan-reyes']
  const [openSources, setOpenSources] = useState<Set<string>>(new Set())
  const [activeTab, setActiveTab] = useState<'positions' | 'statements' | 'bio' | 'finance' | 'sources'>('positions')
  const [sourceModalOpen, setSourceModalOpen] = useState(false)

  const toggleSource = (id: string) =>
    setOpenSources((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })

  const TABS = [
    { id: 'positions' as const, label: 'Policy Positions' },
    { id: 'statements' as const, label: 'Public Statements' },
    { id: 'bio' as const, label: 'Biography' },
    { id: 'finance' as const, label: 'Campaign Finance' },
    { id: 'sources' as const, label: 'All Sources' },
  ]

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Breadcrumb */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex items-center gap-2 text-xs text-muted">
            <button onClick={() => navigate('home')} className="hover:text-civic transition-colors">Home</button>
            <span className="text-border">/</span>
            <button onClick={() => navigate('elections')} className="hover:text-civic transition-colors">Elections</button>
            <span className="text-border">/</span>
            <button onClick={() => navigate('race')} className="hover:text-civic transition-colors">City Council — District 3</button>
            <span className="text-border">/</span>
            <span className="text-navy font-medium">{candidate.name}</span>
          </div>
        </div>
      </div>

      {/* Profile header */}
      <div className="bg-navy">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <Avatar initials={candidate.photoPlaceholder} index={0} size="lg" />

            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <PartyLabel party={candidate.party} />
                <span className="text-blue-300/60 text-xs">·</span>
                <span className="text-blue-300 text-xs">{candidate.occupation}</span>
              </div>
              <h1
                className="text-3xl sm:text-4xl font-bold text-white mb-2 leading-tight"
                style={{ fontFamily: 'Fraunces, Georgia, serif' }}
              >
                {candidate.name}
              </h1>
              <p className="text-blue-200/80 text-sm mb-3">
                Running for City Council — District 3 · City of Riverside · Election: {candidate.lastUpdated ? 'November 4, 2025' : ''}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {candidate.issues.map((issue) => <IssueTag key={issue} label={issue} />)}
              </div>
            </div>

            <div className="flex flex-col items-start sm:items-end gap-3 shrink-0">
              {/* Confidence widget */}
              <div className="bg-navy-mid rounded-xl px-4 py-3 border border-white/8">
                <p className="text-[10px] text-blue-300/70 uppercase tracking-wide mb-2">Information quality</p>
                <ConfidenceIndicator level={candidate.confidence} showLabel />
                <p className="text-[10px] text-blue-300/50 mt-1.5">Updated {candidate.lastUpdated}</p>
              </div>

              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => navigate('comparison')}
                  className="px-3.5 py-2 rounded-lg border border-white/20 text-white text-xs font-medium hover:bg-white/10 transition-colors"
                >
                  Compare
                </button>
                <button
                  onClick={() => setSourceModalOpen(true)}
                  className="px-3.5 py-2 rounded-lg border border-white/20 text-white text-xs font-medium hover:bg-white/10 transition-colors"
                >
                  View Sources
                </button>
                <a
                  href="#"
                  className="px-3.5 py-2 rounded-lg bg-civic text-white text-xs font-medium hover:bg-civic-hover transition-colors"
                >
                  Campaign site ↗
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-surface border-b border-border sticky top-[60px] z-40">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="flex gap-0 overflow-x-auto">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-4 text-sm font-medium whitespace-nowrap border-b-2 transition-all ${
                  activeTab === tab.id
                    ? 'border-civic text-civic'
                    : 'border-transparent text-muted hover:text-navy hover:border-border-strong'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Placeholder notice */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <PlaceholderBadge text="Jordan Reyes is a fictional sample candidate — all data here is placeholder for design purposes" />
          <Disclaimer>
            Information on this page may be incomplete, pending update, or based on limited evidence. Always verify with official sources.
          </Disclaimer>
        </div>

        {/* ─ Policy Positions ─ */}
        {activeTab === 'positions' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-navy text-lg" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Policy positions</h2>
              <Tooltip content="Hover any evidence badge for an explanation of what it means.">
                <span className="text-xs text-muted border border-border rounded-lg px-3 py-1.5 cursor-default hover:border-border-strong transition-colors">
                  Evidence legend ⓘ
                </span>
              </Tooltip>
            </div>

            {/* Legend */}
            <div className="bg-surface rounded-xl border border-border p-4">
              <p className="text-xs font-medium text-muted uppercase tracking-wide mb-3">Evidence types used on this page</p>
              <div className="flex flex-wrap gap-2">
                {(['verified-fact', 'candidate-provided', 'public-statement', 'voting-record', 'third-party', 'ai-interpreted', 'unclear', 'unavailable'] as const).map((type) => (
                  <EvidenceBadge key={type} type={type} size="xs" withTooltip />
                ))}
              </div>
            </div>

            {candidate.positions.map((position) => (
              <div
                key={position.issue}
                className={`bg-surface rounded-xl border p-5 transition-shadow hover:shadow-sm ${
                  position.evidenceType === 'unavailable' || position.evidenceType === 'unclear'
                    ? 'border-border opacity-80'
                    : 'border-border'
                }`}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <h3 className="font-semibold text-navy text-[15px]" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                    {position.issue}
                  </h3>
                  <EvidenceBadge type={position.evidenceType} withTooltip />
                </div>

                <p className="text-sm font-medium text-navy/85 mb-2">{position.summary}</p>

                {position.evidenceType !== 'unavailable' && (
                  <>
                    <p className="text-sm text-muted leading-relaxed mb-4">{position.detail}</p>
                    {position.evidenceType !== 'unclear' && (
                      <PolicyScaleBar value={position.scale} label="Estimated position on this issue" />
                    )}
                  </>
                )}

                {(position.evidenceType === 'ai-interpreted') && (
                  <div className="mt-3">
                    <Alert type="warning">
                      <strong>AI-assisted interpretation:</strong> This position was inferred by AI from general statements. It is given reduced weight in match calculations and should be verified independently.
                    </Alert>
                  </div>
                )}

                <SourcePanel
                  sources={position.sources}
                  isOpen={openSources.has(position.issue)}
                  onToggle={() => toggleSource(position.issue)}
                />
              </div>
            ))}
          </div>
        )}

        {/* ─ Public Statements ─ */}
        {activeTab === 'statements' && (
          <div className="space-y-4">
            <h2 className="font-semibold text-navy text-lg" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Public statements</h2>
            <Alert type="info">
              Statements below are drawn from recorded public forums, interviews, and published writings. Each is labeled with its source context. Statements represent the candidate's own words; they are not summarized or paraphrased.
            </Alert>

            {SAMPLE_STATEMENTS.map((stmt, i) => (
              <div key={i} className="bg-surface rounded-xl border border-border p-5">
                <div className="flex gap-3">
                  <div className="w-0.5 bg-civic rounded-full shrink-0 self-stretch" />
                  <div>
                    <blockquote className="text-navy text-[15px] leading-relaxed font-medium mb-3 italic">
                      "{stmt.quote}"
                    </blockquote>
                    <div className="flex flex-wrap items-center gap-2">
                      <EvidenceBadge type="public-statement" size="xs" />
                      <span className="text-xs text-muted">{stmt.context}</span>
                      <span className="text-border">·</span>
                      <span className="text-xs text-muted">{stmt.outlet}</span>
                      <span className="text-border">·</span>
                      <span className="text-xs text-muted">{stmt.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <div className="text-center pt-4">
              <p className="text-xs text-muted">Showing {SAMPLE_STATEMENTS.length} of 8 statements. <button className="text-civic underline">Load all statements</button></p>
            </div>
          </div>
        )}

        {/* ─ Biography ─ */}
        {activeTab === 'bio' && (
          <div className="space-y-5">
            <div className="bg-surface rounded-xl border border-border p-6">
              <h2 className="font-semibold text-navy text-lg mb-4" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Biography</h2>
              <div className="flex items-start gap-2 mb-4">
                <EvidenceBadge type="candidate-provided" size="xs" />
                <span className="text-xs text-muted">Source: candidate-provided voter guide submission</span>
              </div>
              <p className="text-sm text-navy/70 leading-relaxed mb-6">{candidate.bio}</p>

              <h3 className="font-semibold text-navy text-sm mb-3" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Professional experience</h3>
              <ul className="space-y-2.5">
                {candidate.experience.map((exp) => (
                  <li key={exp} className="flex items-start gap-3 text-sm text-navy/70">
                    <div className="w-1.5 h-1.5 rounded-full bg-civic shrink-0 mt-1.5" />
                    {exp}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-surface rounded-xl border border-border p-6">
              <h3 className="font-semibold text-navy mb-3" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Endorsements</h3>
              <div className="flex flex-wrap gap-2">
                {candidate.endorsements.map((e) => (
                  <span key={e} className="text-xs px-3 py-1.5 rounded-full bg-soft border border-border text-navy/65">
                    {e}
                  </span>
                ))}
              </div>
            </div>

            {/* Voting record note */}
            <div className="bg-surface rounded-xl border border-border p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-navy" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Voting record</h3>
                <EvidenceBadge type="unavailable" size="xs" />
              </div>
              <p className="text-sm text-muted leading-relaxed">
                Jordan Reyes has not previously held elected office. No voting record is available for this race. Prior board or commission votes, if any, will be added when documentation is obtained.
              </p>
            </div>
          </div>
        )}

        {/* ─ Campaign Finance ─ */}
        {activeTab === 'finance' && (
          <div className="space-y-5">
            <div className="bg-surface rounded-xl border border-border p-6">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-semibold text-navy text-lg" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Campaign finance summary</h2>
                <EvidenceBadge type="verified-fact" withTooltip />
              </div>

              <div className="grid sm:grid-cols-2 gap-4 mb-6">
                <div className="bg-teal-light rounded-2xl p-5 border border-teal/20">
                  <p className="text-xs text-teal/70 uppercase tracking-wide font-medium mb-1">Total raised</p>
                  <p className="text-3xl font-bold text-teal font-mono">{candidate.finance.raised}</p>
                  <p className="text-[11px] text-teal/60 mt-1">Through April 30, 2025</p>
                </div>
                <div className="bg-soft rounded-2xl p-5 border border-border">
                  <p className="text-xs text-muted uppercase tracking-wide font-medium mb-1">Total spent</p>
                  <p className="text-3xl font-bold text-navy font-mono">{candidate.finance.spent}</p>
                  <p className="text-[11px] text-muted mt-1">Through April 30, 2025</p>
                </div>
              </div>

              <h3 className="font-semibold text-navy text-sm mb-3" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>Top donor categories</h3>
              <ul className="space-y-2 mb-5">
                {candidate.finance.topDonors.map((donor) => (
                  <li key={donor} className="flex items-start gap-3 text-sm text-navy/70">
                    <div className="w-1.5 h-1.5 rounded-full bg-civic shrink-0 mt-1.5" />
                    {donor}
                  </li>
                ))}
              </ul>

              <div className="pt-4 border-t border-border text-xs text-muted">
                Financial data sourced from candidate disclosure filings with the Riverside City Clerk. <a href="#" className="text-civic underline hover:text-civic-light">View original filings ↗</a>
              </div>
            </div>
          </div>
        )}

        {/* ─ All Sources ─ */}
        {activeTab === 'sources' && (
          <div className="bg-surface rounded-xl border border-border p-6">
            <h2 className="font-semibold text-navy text-lg mb-5" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
              Complete source list
            </h2>

            <div className="space-y-1">
              {[
                ...candidate.sources,
                ...candidate.positions.flatMap((p) => p.sources),
              ].map((source, i) => (
                <div key={i} className="flex items-start justify-between gap-4 py-3 border-b border-border last:border-0">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <EvidenceBadge type={source.type} size="xs" withTooltip />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-navy truncate">"{source.title}"</p>
                      <p className="text-xs text-muted mt-0.5">{source.outlet} · {source.date}</p>
                    </div>
                  </div>
                  <a href={source.url} className="text-xs text-civic hover:text-civic-light font-medium shrink-0">View ↗</a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sources modal */}
      <Modal open={sourceModalOpen} onClose={() => setSourceModalOpen(false)} title="All Sources" size="lg">
        <div className="space-y-1 max-h-[60vh] overflow-y-auto">
          {[...candidate.sources, ...candidate.positions.flatMap((p) => p.sources)].map((source, i) => (
            <SourceCitation
              key={i}
              title={source.title}
              outlet={source.outlet}
              date={source.date}
              url={source.url}
              type={source.type}
            />
          ))}
        </div>
      </Modal>
    </div>
  )
}
