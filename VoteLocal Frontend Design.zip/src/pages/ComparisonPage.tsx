import { useState } from 'react'
import { useNav } from '../context/nav'
import { CANDIDATES } from '../data/placeholder'
import { EvidenceBadge, PartyLabel, MissingInfoBanner, PolicyScaleBar } from '../components/Badges'
import { Avatar } from '../components/Cards'
import { PlaceholderBadge, Alert } from '../components/ui'
import type { Candidate } from '../types'

const ISSUES = [
  'Housing & Development',
  'Public Safety',
  'Local Taxes & Spending',
  'Education',
  'Transportation',
  'Environment',
  'Government Transparency',
]

// ─── Candidate column header ──────────────────────────────────────────────────

function CandidateHeader({
  candidate,
  index,
  onRemove,
}: {
  candidate: Candidate
  index: number
  onRemove: () => void
}) {
  return (
    <div className="relative bg-surface rounded-xl border border-border p-4">
      <button
        onClick={onRemove}
        className="absolute top-2.5 right-2.5 w-6 h-6 rounded-lg flex items-center justify-center text-muted hover:text-red-500 hover:bg-red-50 transition-colors"
        aria-label={`Remove ${candidate.name}`}
      >
        <svg viewBox="0 0 12 12" fill="currentColor" className="w-3.5 h-3.5">
          <path d="M2.22 2.22a.75.75 0 011.06 0L6 4.94l2.72-2.72a.75.75 0 111.06 1.06L7.06 6l2.72 2.72a.75.75 0 11-1.06 1.06L6 7.06 3.28 9.78a.75.75 0 01-1.06-1.06L4.94 6 2.22 3.28a.75.75 0 010-1.06z"/>
        </svg>
      </button>

      <div className="flex items-center gap-3 mb-2 pr-6">
        <Avatar initials={candidate.photoPlaceholder} index={index} size="sm" />
        <div className="min-w-0">
          <p className="font-semibold text-navy text-sm leading-snug" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
            {candidate.name}
          </p>
          <PartyLabel party={candidate.party} />
        </div>
      </div>
      <p className="text-xs text-muted">{candidate.occupation}</p>
    </div>
  )
}

// ─── Position scale mini ──────────────────────────────────────────────────────

function MiniScale({ value }: { value: number | null }) {
  if (value === null) return <span className="text-xs text-muted italic">Not available</span>
  const pct = ((value - 1) / 4) * 100
  return (
    <div className="flex items-center gap-1.5 w-full">
      <span className="text-[9px] text-muted shrink-0">Cons.</span>
      <div className="relative flex-1 h-1.5 bg-soft-mid rounded-full">
        <div className="absolute inset-y-0 left-0 bg-civic rounded-full transition-all" style={{ width: `${pct}%` }} />
        <div
          className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white border-2 border-civic rounded-full shadow-sm"
          style={{ left: `calc(${pct}% - 6px)` }}
        />
      </div>
      <span className="text-[9px] text-muted shrink-0">Prog.</span>
    </div>
  )
}

// ─── ComparisonPage ───────────────────────────────────────────────────────────

export default function ComparisonPage() {
  const { navigate } = useNav()
  const allCandidates = Object.values(CANDIDATES)
  const [shown, setShown] = useState<string[]>(['jordan-reyes', 'patricia-chen'])
  const [openEvidence, setOpenEvidence] = useState<Set<string>>(new Set())

  const remove = (id: string) => setShown((prev) => prev.filter((x) => x !== id))
  const add = (id: string) => { if (shown.length < 4) setShown((prev) => [...prev, id]) }

  const candidates = shown.map((id) => CANDIDATES[id]).filter(Boolean)
  const n = candidates.length

  const getPos = (candidate: Candidate, issue: string) =>
    candidate.positions.find((p) => p.issue === issue) ?? null

  const gridCols = {
    1: 'grid-cols-2',
    2: 'grid-cols-3',
    3: 'grid-cols-4',
    4: 'grid-cols-5',
  }[n] ?? 'grid-cols-3'

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Header */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2 text-xs text-muted mb-3">
            <button onClick={() => navigate('home')} className="hover:text-civic">Home</button>
            <span>/</span>
            <button onClick={() => navigate('race')} className="hover:text-civic">City Council — D3</button>
            <span>/</span>
            <span className="text-navy font-medium">Compare Candidates</span>
          </div>
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-2xl font-bold text-navy" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                Compare Candidates
              </h1>
              <p className="text-sm text-muted mt-1">City Council — District 3 · City of Riverside</p>
            </div>
            <button
              onClick={() => navigate('quiz')}
              className="px-4 py-2 rounded-xl bg-teal text-white text-sm font-semibold hover:bg-teal-hover transition-colors"
            >
              Take the Quiz →
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Notices */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6 flex-wrap">
          <PlaceholderBadge />
          <div className="flex-1">
            <Alert type="info">
              Position scales and comparisons are based on available public statements and candidate-provided materials. Uncertain, incomplete, or AI-assisted positions are clearly labeled. This comparison is not an endorsement. Use alongside independent research.
            </Alert>
          </div>
        </div>

        {/* Candidate headers row */}
        <div className={`grid ${gridCols} gap-3 mb-6`}>
          {/* Empty label column */}
          <div className="hidden sm:block" />
          {candidates.map((c, i) => (
            <CandidateHeader key={c.id} candidate={c} index={i} onRemove={() => remove(c.id)} />
          ))}
          {/* Add candidate slot */}
          {shown.length < 4 && (
            <div className="bg-surface rounded-xl border-2 border-dashed border-border p-4 flex flex-col items-center justify-center gap-2 min-h-[96px]">
              <p className="text-xs text-muted text-center">Add candidate</p>
              <select
                className="w-full text-xs py-1.5 px-2 rounded-lg border border-border text-navy bg-soft focus:outline-none focus:ring-1 focus:ring-civic"
                value=""
                onChange={(e) => { if (e.target.value) add(e.target.value) }}
              >
                <option value="">Select…</option>
                {allCandidates.filter((c) => !shown.includes(c.id)).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Issue rows */}
        <div className="bg-surface rounded-2xl border border-border overflow-hidden">
          {/* Table header */}
          <div className={`grid ${gridCols} bg-soft border-b border-border`}>
            <div className="px-4 py-2.5">
              <span className="text-xs font-mono font-medium text-muted uppercase tracking-widest">Issue</span>
            </div>
            {candidates.map((c) => (
              <div key={c.id} className="px-4 py-2.5 border-l border-border">
                <span className="text-xs font-semibold text-navy truncate block">{c.name.split(' ')[0]}</span>
              </div>
            ))}
            {shown.length < 4 && <div className="border-l border-border" />}
          </div>

          {ISSUES.map((issue, issueIdx) => {
            const positions = candidates.map((c) => getPos(c, issue))
            const evidenceKey = `ev-${issueIdx}`
            const isOpen = openEvidence.has(evidenceKey)

            return (
              <div key={issue} className={`${issueIdx < ISSUES.length - 1 ? 'border-b border-border' : ''}`}>
                {/* Issue label + summary row */}
                <div className={`grid ${gridCols}`}>
                  <div className="bg-soft/60 px-4 py-3.5 flex flex-col justify-center border-r border-border">
                    <p className="text-xs font-semibold text-navy">{issue}</p>
                    <button
                      onClick={() => {
                        setOpenEvidence((prev) => {
                          const next = new Set(prev)
                          isOpen ? next.delete(evidenceKey) : next.add(evidenceKey)
                          return next
                        })
                      }}
                      className="mt-1.5 text-[10px] text-civic font-medium hover:text-civic-light flex items-center gap-1 transition-colors"
                    >
                      <svg viewBox="0 0 10 10" fill="currentColor" className={`w-2.5 h-2.5 transition-transform ${isOpen ? 'rotate-90' : ''}`}>
                        <path fillRule="evenodd" clipRule="evenodd" d="M3.16 3.66a.5.5 0 01.7 0L6 5.8l2.14-2.14a.5.5 0 01.7.7L6.35 6.86a.5.5 0 01-.7 0L3.16 4.36a.5.5 0 010-.7z"/>
                      </svg>
                      Evidence
                    </button>
                  </div>

                  {candidates.map((c, ci) => {
                    const pos = positions[ci]
                    return (
                      <div key={c.id} className="px-4 py-3.5 border-l border-border">
                        {/* Evidence badge */}
                        <div className="mb-2">
                          <EvidenceBadge type={pos?.evidenceType ?? 'unavailable'} size="xs" withTooltip />
                        </div>
                        {/* Summary */}
                        <p className={`text-xs leading-relaxed mb-2.5 ${pos ? 'text-navy/75' : 'text-muted italic'}`}>
                          {pos ? pos.summary : 'No information available for this issue.'}
                        </p>
                        {/* Scale */}
                        {pos && pos.evidenceType !== 'unavailable' && pos.evidenceType !== 'unclear' && (
                          <MiniScale value={pos.scale} />
                        )}
                        {!pos && <MiniScale value={null} />}
                      </div>
                    )
                  })}

                  {shown.length < 4 && <div className="border-l border-border" />}
                </div>

                {/* Evidence panel */}
                {isOpen && (
                  <div className={`grid ${gridCols} border-t border-border/50 bg-soft/30`}>
                    <div className="px-4 py-3 border-r border-border">
                      <p className="text-[10px] text-muted italic font-medium uppercase tracking-wide">Sources</p>
                    </div>
                    {candidates.map((c, ci) => {
                      const pos = positions[ci]
                      return (
                        <div key={c.id} className="px-4 py-3 border-l border-border space-y-1.5">
                          {pos && pos.sources.length > 0 ? (
                            pos.sources.map((s, si) => (
                              <div key={si} className="text-[10px] text-muted">
                                <p className="font-medium text-navy/60 truncate">{s.outlet}</p>
                                <p className="italic truncate">"{s.title}"</p>
                                <p>{s.date}</p>
                              </div>
                            ))
                          ) : (
                            <p className="text-[10px] text-muted italic">No sources available</p>
                          )}
                        </div>
                      )
                    })}
                    {shown.length < 4 && <div className="border-l border-border" />}
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* Missing info + CTA */}
        <div className="mt-6 space-y-4">
          <MissingInfoBanner text="Some positions are missing, based on limited evidence, or AI-interpreted. Positions labeled 'AI-Assisted' or 'Unclear' should be verified with independent research before making voting decisions." />

          <div className="bg-navy rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
            <div>
              <p className="font-semibold text-white text-lg" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                See how these candidates compare to your own views
              </p>
              <p className="text-blue-200/80 text-sm mt-1">
                Take the 15-question questionnaire for a personalized alignment estimate.
              </p>
            </div>
            <button
              onClick={() => navigate('quiz')}
              className="shrink-0 px-6 py-3 rounded-xl bg-teal text-white font-semibold hover:bg-teal-hover transition-colors"
            >
              Take the Quiz →
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
