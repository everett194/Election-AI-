import { useState } from 'react'
import { useNav } from '../context/nav'
import { RACES } from '../data/placeholder'
import { RaceCard, RaceCardSkeleton } from '../components/Cards'
import { EmptyState, ErrorState, PlaceholderBadge } from '../components/ui'

type LoadState = 'loaded' | 'loading' | 'empty' | 'not-found' | 'error'

const JURISDICTIONS = ['all', 'City of Riverside', 'Riverside Unified School District', 'Riverside County']

export default function ElectionResultsPage() {
  const { navigate } = useNav()
  const [loadState, setLoadState] = useState<LoadState>('loaded')
  const [search, setSearch] = useState('')
  const [filterJurisdiction, setFilterJurisdiction] = useState('all')

  const filteredRaces = RACES.filter((race) => {
    const matchSearch = !search ||
      race.office.toLowerCase().includes(search.toLowerCase()) ||
      race.jurisdiction.toLowerCase().includes(search.toLowerCase())
    const matchJurisdiction = filterJurisdiction === 'all' || race.jurisdiction === filterJurisdiction
    return matchSearch && matchJurisdiction
  })

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Page header */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2 text-xs text-muted mb-3">
            <button onClick={() => navigate('home')} className="hover:text-civic transition-colors">Home</button>
            <span className="text-border">/</span>
            <span className="text-navy font-medium">Elections</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-navy mb-1.5" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                Elections in Riverside, CA 92501
              </h1>
              <div className="flex flex-wrap items-center gap-3 text-sm text-muted">
                <span className="inline-flex items-center gap-1.5">
                  <svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5 text-civic-light">
                    <path fillRule="evenodd" clipRule="evenodd" d="M2 2a1 1 0 011-1h8a1 1 0 011 1v1h1a1 1 0 011 1v8a1 1 0 01-1 1H1a1 1 0 01-1-1V4a1 1 0 011-1h1V2zm8 2H4v7h6V4z"/>
                  </svg>
                  Next election: <strong className="text-navy">November 4, 2025</strong>
                </span>
                <a href="#" className="inline-flex items-center gap-1 text-civic hover:text-civic-light font-medium underline underline-offset-2 text-sm">
                  Official Riverside County Elections ↗
                </a>
              </div>
            </div>
            <PlaceholderBadge />
          </div>
        </div>
      </div>

      {/* Sticky filters */}
      <div className="bg-surface border-b border-border sticky top-[60px] z-30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3">
          <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
            {/* Search */}
            <div className="relative flex-1 max-w-sm">
              <svg viewBox="0 0 18 18" fill="currentColor" className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted pointer-events-none">
                <path fillRule="evenodd" clipRule="evenodd" d="M7 2a5 5 0 100 10A5 5 0 007 2zm-7 5a7 7 0 1112.6 4.2l4.1 4.1a1 1 0 01-1.4 1.4L11.2 12.6A7 7 0 010 7z"/>
              </svg>
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search races or offices…"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-border text-sm bg-soft text-navy placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-civic focus:border-transparent transition-all"
              />
            </div>

            {/* Jurisdiction filter */}
            <select
              value={filterJurisdiction}
              onChange={(e) => setFilterJurisdiction(e.target.value)}
              className="py-2.5 px-3.5 pr-8 rounded-xl border border-border text-sm bg-soft text-navy focus:outline-none focus:ring-2 focus:ring-civic transition-all appearance-none"
              style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%236b7a99'%3E%3Cpath fill-rule='evenodd' d='M4.22 6.22a.75.75 0 011.06 0L8 8.94l2.72-2.72a.75.75 0 111.06 1.06l-3.25 3.25a.75.75 0 01-1.06 0L4.22 7.28a.75.75 0 010-1.06z'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center', backgroundSize: '16px' }}
            >
              {JURISDICTIONS.map((j) => (
                <option key={j} value={j}>{j === 'all' ? 'All jurisdictions' : j}</option>
              ))}
            </select>

            <select
              className="py-2.5 px-3.5 pr-8 rounded-xl border border-border text-sm bg-soft text-navy focus:outline-none focus:ring-2 focus:ring-civic transition-all appearance-none"
              style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%236b7a99'%3E%3Cpath fill-rule='evenodd' d='M4.22 6.22a.75.75 0 011.06 0L8 8.94l2.72-2.72a.75.75 0 111.06 1.06l-3.25 3.25a.75.75 0 01-1.06 0L4.22 7.28a.75.75 0 010-1.06z'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center', backgroundSize: '16px' }}
            >
              <option>All election dates</option>
              <option>November 4, 2025</option>
            </select>

            {/* State demo toggles */}
            <div className="flex gap-1.5 ml-auto">
              {(['loaded','loading','empty','not-found','error'] as LoadState[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setLoadState(s)}
                  className={`text-[10px] px-2 py-1 rounded-md border font-medium transition-colors ${
                    loadState === s ? 'bg-navy text-white border-navy' : 'bg-surface text-muted border-border hover:border-border-strong'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Visual states */}
        {loadState === 'loading' && (
          <div className="grid md:grid-cols-2 gap-5">
            {[1, 2, 3, 4].map((i) => <RaceCardSkeleton key={i} />)}
          </div>
        )}

        {loadState === 'not-found' && (
          <EmptyState
            icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-7 h-7"><path strokeLinecap="round" strokeLinejoin="round" d="M15.182 16.318A4.486 4.486 0 0012.016 15a4.486 4.486 0 00-3.198 1.318M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z"/></svg>}
            title="Location not recognised"
            description="We couldn't find election data for that location. Try a different ZIP code or check the spelling of your address."
            action={<button onClick={() => navigate('home')} className="px-4 py-2 rounded-xl bg-civic text-white text-sm font-semibold hover:bg-civic-hover transition-colors">Try another address</button>}
          />
        )}

        {loadState === 'empty' && (
          <EmptyState
            icon={<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-7 h-7"><path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 9v7.5"/></svg>}
            title="No upcoming elections found"
            description="No elections are scheduled in your area in the next 12 months. Check back closer to election season."
          />
        )}

        {loadState === 'error' && (
          <ErrorState
            title="Election data temporarily unavailable"
            description="We're unable to load election information right now. Please try again or visit the official elections website directly."
            onRetry={() => setLoadState('loaded')}
          />
        )}

        {loadState === 'loaded' && (
          <>
            {filteredRaces.length === 0 ? (
              <EmptyState
                title="No races match your search"
                description="Try different search terms or clear your filters."
                action={<button className="text-sm text-civic underline" onClick={() => { setSearch(''); setFilterJurisdiction('all') }}>Clear all filters</button>}
              />
            ) : (
              <div className="space-y-10">
                {JURISDICTIONS.filter((j) => j !== 'all').map((jur) => {
                  const races = filteredRaces.filter((r) => r.jurisdiction === jur)
                  if (!races.length) return null
                  return (
                    <div key={jur}>
                      <div className="flex items-center gap-3 mb-5">
                        <h2 className="text-xs font-mono font-semibold text-muted uppercase tracking-widest whitespace-nowrap">{jur}</h2>
                        <div className="flex-1 h-px bg-border" />
                        <span className="text-xs text-muted font-mono shrink-0">{races.length} {races.length === 1 ? 'race' : 'races'}</span>
                      </div>
                      <div className="grid md:grid-cols-2 gap-5">
                        {races.map((race) => (
                          <RaceCard
                            key={race.id}
                            race={race}
                            onViewCandidates={() => navigate('race')}
                            onTakeQuiz={() => navigate('quiz')}
                          />
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            <div className="mt-10 pt-6 border-t border-border text-xs text-muted flex items-start gap-2.5">
              <svg viewBox="0 0 14 14" fill="currentColor" className="w-4 h-4 shrink-0 text-civic-light mt-0.5">
                <path fillRule="evenodd" clipRule="evenodd" d="M7 1a6 6 0 100 12A6 6 0 007 1zm-.75 3.25a.75.75 0 011.5 0v3a.75.75 0 01-1.5 0v-3zm.75 5.5a.75.75 0 100-1.5.75.75 0 000 1.5z"/>
              </svg>
              <p>Race information is sourced from official election authority filings. Candidate counts and election dates may change before filing deadlines. Always verify with <a href="#" className="text-civic underline hover:text-civic-light">official Riverside County Elections</a> sources. <span className="text-amber-600">Placeholder data shown for design purposes.</span></p>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
