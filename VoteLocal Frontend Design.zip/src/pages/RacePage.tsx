import { useState } from 'react'
import { useNav } from '../context/nav'
import { CANDIDATES, RACES } from '../data/placeholder'
import { CandidateCard, CandidateCardSkeleton } from '../components/Cards'
import { PlaceholderBadge } from '../components/ui'

export default function RacePage() {
  const { navigate } = useNav()
  const race = RACES[0]
  const candidates = race.candidateIds.map((id) => CANDIDATES[id]).filter(Boolean)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [loading] = useState(false)

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else if (next.size < 4) next.add(id)
      return next
    })
  }

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Header */}
      <div className="bg-surface border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2 text-xs text-muted mb-3">
            <button onClick={() => navigate('home')} className="hover:text-civic transition-colors">Home</button>
            <span className="text-border">/</span>
            <button onClick={() => navigate('elections')} className="hover:text-civic transition-colors">Elections</button>
            <span className="text-border">/</span>
            <span className="text-navy font-medium">{race.office}</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-5">
            <div>
              <h1 className="text-2xl font-bold text-navy mb-1.5" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                {race.office}
              </h1>
              <div className="flex flex-wrap items-center gap-3 text-sm text-muted">
                <span>{race.jurisdiction}</span>
                <span className="text-border">·</span>
                <span className="inline-flex items-center gap-1.5">
                  <svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5 text-civic-light">
                    <path fillRule="evenodd" clipRule="evenodd" d="M2 2a1 1 0 011-1h8a1 1 0 011 1v1h1a1 1 0 011 1v8a1 1 0 01-1 1H1a1 1 0 01-1-1V4a1 1 0 011-1h1V2zm8 2H4v7h6V4z"/>
                  </svg>
                  {race.electionDate}
                </span>
                <span className="text-border">·</span>
                <span className="text-xs font-mono font-medium text-civic bg-civic-pale px-2 py-0.5 rounded-lg border border-civic/20">
                  {race.candidateCount} candidates
                </span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2.5">
              {selected.size >= 2 && (
                <button
                  onClick={() => navigate('comparison')}
                  className="px-4 py-2.5 rounded-xl bg-navy text-white text-sm font-semibold hover:bg-navy-mid transition-colors"
                >
                  Compare {selected.size} →
                </button>
              )}
              <button
                onClick={() => navigate('quiz')}
                className="px-4 py-2.5 rounded-xl bg-teal text-white text-sm font-semibold hover:bg-teal-hover transition-colors"
              >
                Take the Quiz
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
          <PlaceholderBadge text="Fictional candidates — placeholder data for design purposes" />
        </div>

        {/* Office description */}
        <div className="bg-surface rounded-2xl border border-border p-5 mb-8">
          <h2 className="font-semibold text-navy text-sm mb-2" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
            About this office
          </h2>
          <p className="text-sm text-navy/65 leading-relaxed">{race.description}</p>
        </div>

        {/* Compare banner */}
        {selected.size > 0 && (
          <div className="mb-6 p-4 rounded-xl bg-navy/5 border border-navy/15 flex items-center justify-between gap-4">
            <div className="text-sm">
              <span className="font-semibold text-navy">{selected.size} candidate{selected.size > 1 ? 's' : ''} selected</span>
              <span className="text-muted ml-2 text-xs">(max 4 — need at least 2 to compare)</span>
            </div>
            <div className="flex gap-2">
              <button className="text-xs text-muted hover:text-navy underline" onClick={() => setSelected(new Set())}>Clear</button>
              {selected.size >= 2 && (
                <button
                  onClick={() => navigate('comparison')}
                  className="px-3.5 py-1.5 rounded-lg bg-civic text-white text-xs font-semibold hover:bg-civic-hover transition-colors"
                >
                  Compare →
                </button>
              )}
            </div>
          </div>
        )}

        {/* Candidates */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3].map((i) => <CandidateCardSkeleton key={i} />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {candidates.map((candidate, idx) => (
              <CandidateCard
                key={candidate.id}
                candidate={candidate}
                index={idx}
                onViewProfile={() => navigate('candidate')}
                selected={selected.has(candidate.id)}
                onToggleCompare={() => toggleSelect(candidate.id)}
                showCompare
              />
            ))}
          </div>
        )}

        {/* Quiz CTA */}
        <div className="mt-12 bg-navy rounded-2xl p-8 text-center">
          <h2 className="text-xl font-bold text-white mb-2" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
            Not sure who aligns with your priorities?
          </h2>
          <p className="text-blue-200/80 text-sm mb-5 max-w-lg mx-auto">
            Take the 15-question questionnaire to see your estimated alignment with each candidate. Results include confidence levels and are clearly labeled as estimates — not predictions or endorsements.
          </p>
          <button
            onClick={() => navigate('quiz')}
            className="px-6 py-3 rounded-xl bg-teal text-white font-semibold hover:bg-teal-hover transition-colors"
          >
            Take the Questionnaire
          </button>
        </div>
      </div>
    </div>
  )
}
