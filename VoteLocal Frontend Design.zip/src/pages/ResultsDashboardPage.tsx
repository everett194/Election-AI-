import { useState } from 'react'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  ResponsiveContainer, Tooltip as RechartsTooltip,
} from 'recharts'
import { useNav } from '../context/nav'
import { CANDIDATES } from '../data/placeholder'
import { ConfidenceIndicator, PartyLabel, EvidenceBadge } from '../components/Badges'
import { Avatar } from '../components/Cards'
import { Alert, PlaceholderBadge } from '../components/ui'

/**
 * PLACEHOLDER RESULTS — All percentages, scores, and positions shown here
 * are fictional values for design demonstration only.
 * Real results are calculated by the backend scoring system.
 */

const RESULTS = [
  {
    candidateId: 'jordan-reyes',
    matchEstimate: 78,
    confidence: 4,
    issues: [
      { label: 'Housing',     userVal: 4, candidateVal: 4, aligned: true  },
      { label: 'Safety',      userVal: 3, candidateVal: 3, aligned: true  },
      { label: 'Taxes',       userVal: 3, candidateVal: 3, aligned: true  },
      { label: 'Education',   userVal: 4, candidateVal: 4, aligned: true  },
      { label: 'Transport',   userVal: 5, candidateVal: 5, aligned: true  },
      { label: 'Environment', userVal: 4, candidateVal: 4, aligned: true  },
      { label: 'Transparency',userVal: 4, candidateVal: 3, aligned: false },
    ],
    missingIssues: ['Transparency'],
  },
  {
    candidateId: 'marcus-webb',
    matchEstimate: 64,
    confidence: 3,
    issues: [
      { label: 'Housing',     userVal: 4, candidateVal: 3, aligned: false },
      { label: 'Safety',      userVal: 3, candidateVal: 3, aligned: true  },
      { label: 'Taxes',       userVal: 3, candidateVal: 3, aligned: true  },
      { label: 'Education',   userVal: 4, candidateVal: 3, aligned: false },
      { label: 'Transport',   userVal: 5, candidateVal: 4, aligned: true  },
      { label: 'Environment', userVal: 4, candidateVal: 4, aligned: true  },
      { label: 'Transparency',userVal: 4, candidateVal: 5, aligned: true  },
    ],
    missingIssues: [],
  },
  {
    candidateId: 'patricia-chen',
    matchEstimate: 41,
    confidence: 3,
    issues: [
      { label: 'Housing',     userVal: 4, candidateVal: 2, aligned: false },
      { label: 'Safety',      userVal: 3, candidateVal: 4, aligned: false },
      { label: 'Taxes',       userVal: 3, candidateVal: 1, aligned: false },
      { label: 'Education',   userVal: 4, candidateVal: 3, aligned: false },
      { label: 'Transport',   userVal: 5, candidateVal: 2, aligned: false },
      { label: 'Environment', userVal: 4, candidateVal: 2, aligned: false },
      { label: 'Transparency',userVal: 4, candidateVal: 4, aligned: true  },
    ],
    missingIssues: ['Education', 'Environment'],
  },
]

const RADAR_DATA = [
  { s: 'Housing',      JR: 80, MW: 65, PC: 40 },
  { s: 'Safety',       JR: 70, MW: 75, PC: 50 },
  { s: 'Taxes',        JR: 72, MW: 68, PC: 30 },
  { s: 'Education',    JR: 78, MW: 60, PC: 42 },
  { s: 'Transport',    JR: 90, MW: 80, PC: 35 },
  { s: 'Environment',  JR: 85, MW: 82, PC: 40 },
  { s: 'Transparency', JR: 60, MW: 90, PC: 65 },
]

// Placeholder compass positions (economic x, social y)
const COMPASS = [
  { id: 'jordan-reyes',  name: 'Jordan Reyes', initials: 'JR', x: -1.2, y:  1.4 },
  { id: 'marcus-webb',   name: 'Marcus Webb',  initials: 'MW', x: -0.4, y:  0.8 },
  { id: 'patricia-chen', name: 'Patricia Chen',initials: 'PC', x:  1.6, y: -0.6 },
]
const USER_XY = { x: -0.8, y: 1.0 }

// ─── Compass SVG ─────────────────────────────────────────────────────────────

function CompassChart() {
  const S = 280
  const PAD = 36
  const inner = S - PAD * 2
  const cvt = (v: number) => ((v + 2) / 4) * inner + PAD

  return (
    <div className="flex flex-col items-center">
      <svg width={S} height={S} aria-label="Governance compass chart showing candidate and user positions">
        {/* Quadrant backgrounds */}
        <rect x={PAD} y={PAD} width={inner / 2} height={inner / 2} fill="#eef3fb" opacity="0.5" />
        <rect x={S / 2} y={S / 2} width={inner / 2} height={inner / 2} fill="#fdf3e0" opacity="0.4" />

        {/* Grid */}
        <line x1={PAD} y1={S / 2} x2={S - PAD} y2={S / 2} stroke="#dde3ed" strokeWidth="1.5"/>
        <line x1={S / 2} y1={PAD} x2={S / 2} y2={S - PAD} stroke="#dde3ed" strokeWidth="1.5"/>

        {/* Axis labels */}
        <text x={S / 2} y={PAD - 8} textAnchor="middle" fill="#6b7a99" fontSize="9" fontWeight="600">MORE SOCIALLY LIBERAL</text>
        <text x={S / 2} y={S - PAD + 16} textAnchor="middle" fill="#6b7a99" fontSize="9" fontWeight="600">MORE SOCIALLY CONSERVATIVE</text>
        <text x={PAD - 6} y={S / 2} textAnchor="middle" fill="#6b7a99" fontSize="9" fontWeight="600"
          transform={`rotate(-90 ${PAD - 6} ${S / 2})`}>ECONOMIC LEFT</text>
        <text x={S - PAD + 6} y={S / 2} textAnchor="middle" fill="#6b7a99" fontSize="9" fontWeight="600"
          transform={`rotate(90 ${S - PAD + 6} ${S / 2})`}>ECONOMIC RIGHT</text>

        {/* User position */}
        <circle cx={cvt(USER_XY.x)} cy={cvt(-USER_XY.y)} r="8" fill="#1a9e87" opacity="0.9"/>
        <circle cx={cvt(USER_XY.x)} cy={cvt(-USER_XY.y)} r="12" fill="#1a9e87" opacity="0.15"/>
        <text x={cvt(USER_XY.x)} y={cvt(-USER_XY.y) - 16} textAnchor="middle" fill="#1a9e87" fontSize="9" fontWeight="700">YOU</text>

        {/* Candidates */}
        {COMPASS.map((c, i) => {
          const cx2 = cvt(c.x)
          const cy2 = cvt(-c.y)
          const colors = ['#2d5fa0', '#1a9e87', '#c9922a']
          const col = colors[i] ?? colors[0]
          return (
            <g key={c.id}>
              <circle cx={cx2} cy={cy2} r="11" fill={col} opacity="0.85"/>
              <text x={cx2} y={cy2 + 4} textAnchor="middle" fill="white" fontSize="8" fontWeight="700">{c.initials}</text>
              <text x={cx2} y={cy2 + 20} textAnchor="middle" fill="#0f2340" fontSize="8" fontWeight="500">{c.name.split(' ')[1]}</text>
            </g>
          )
        })}
      </svg>
      <p className="text-[10px] text-muted text-center mt-1 italic max-w-[220px]">
        Placeholder positions — estimated from available evidence only
      </p>
    </div>
  )
}

// ─── Match card ───────────────────────────────────────────────────────────────

function MatchCard({
  result,
  rank,
  expanded,
  onToggle,
}: {
  result: typeof RESULTS[0]
  rank: number
  expanded: boolean
  onToggle: () => void
}) {
  const { navigate } = useNav()
  const candidate = CANDIDATES[result.candidateId]
  if (!candidate) return null

  const agreements = result.issues.filter((i) => i.aligned)
  const disagreements = result.issues.filter((i) => !i.aligned)

  const barColor = rank === 1 ? 'bg-teal' : rank === 2 ? 'bg-civic' : 'bg-muted/40'
  const pctColor = rank === 1 ? 'text-teal' : rank === 2 ? 'text-civic' : 'text-muted'

  return (
    <div className={`bg-surface rounded-2xl border overflow-hidden transition-shadow hover:shadow-md
      ${rank === 1 ? 'border-teal/40 shadow-sm shadow-teal/10' : 'border-border'}`}>

      {/* Rank banner */}
      {rank === 1 && (
        <div className="bg-teal px-4 py-1.5 flex items-center gap-2 text-white text-xs font-semibold">
          <svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5">
            <path fillRule="evenodd" clipRule="evenodd" d="M7 1a6 6 0 100 12A6 6 0 007 1zm0 10a4 4 0 100-8 4 4 0 000 8zm-.5-6a.5.5 0 011 0v2h1a.5.5 0 010 1H7a.5.5 0 01-.5-.5V5z"/>
          </svg>
          Closest estimated alignment — not an endorsement. Verify with independent research.
        </div>
      )}

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start gap-3.5">
          <Avatar initials={candidate.photoPlaceholder} index={RESULTS.findIndex(r => r.candidateId === result.candidateId)} size="md" />
          <div className="flex-1">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-navy text-base leading-snug" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                  {candidate.name}
                </h3>
                <PartyLabel party={candidate.party} />
              </div>
              <div className="text-right shrink-0">
                <span className={`text-3xl font-bold font-mono ${pctColor}`} style={{ fontFamily: 'DM Mono, monospace' }}>
                  ~{result.matchEstimate}%
                </span>
                <p className="text-[10px] text-muted">estimated alignment</p>
              </div>
            </div>
          </div>
        </div>

        {/* Match bar */}
        <div className="mt-4 h-2.5 bg-soft-mid rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-700 ${barColor}`}
            style={{ width: `${result.matchEstimate}%` }} />
        </div>
        <p className="text-[10px] text-muted mt-1 text-right">{result.matchEstimate}% estimated agreement from available evidence</p>

        {/* Confidence */}
        <div className="mt-3 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-muted-light uppercase tracking-wide mb-1.5">Confidence level</p>
            <ConfidenceIndicator level={result.confidence} showLabel />
          </div>
          <button
            onClick={() => navigate('candidate')}
            className="text-xs text-civic font-medium hover:text-civic-light transition-colors"
          >
            Full profile →
          </button>
        </div>

        {/* Missing info */}
        {result.missingIssues.length > 0 && (
          <div className="mt-3 flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5 shrink-0 text-amber-500">
              <path fillRule="evenodd" clipRule="evenodd" d="M7.485 1.5c-.673-1.167-2.357-1.167-3.03 0L.175 10.667C-.498 11.833.345 13.25 1.69 13.25h10.62c1.346 0 2.188-1.417 1.515-2.583L7.485 1.5zM7 4.75a.75.75 0 01.75.75v2.5a.75.75 0 01-1.5 0v-2.5A.75.75 0 017 4.75zm0 6a.75.75 0 100-1.5.75.75 0 000 1.5z"/>
            </svg>
            Missing information: {result.missingIssues.join(', ')} excluded from calculation.
          </div>
        )}

        {/* Expand */}
        <button
          onClick={onToggle}
          className="mt-4 w-full py-2 rounded-xl border border-border text-xs font-medium text-muted hover:text-navy hover:border-border-strong transition-colors flex items-center justify-center gap-1.5"
        >
          <svg viewBox="0 0 14 14" fill="currentColor" className={`w-3.5 h-3.5 transition-transform ${expanded ? 'rotate-180' : ''}`}>
            <path fillRule="evenodd" clipRule="evenodd" d="M3.72 5.22a.5.5 0 01.7 0L7 7.8l2.58-2.58a.5.5 0 01.7.7L7.35 8.85a.5.5 0 01-.7 0L3.72 5.92a.5.5 0 010-.7z"/>
          </svg>
          {expanded ? 'Hide' : 'Show'} issue-by-issue breakdown
        </button>

        {expanded && (
          <div className="mt-4 space-y-1.5 border-t border-border pt-4">
            <div className="grid grid-cols-3 gap-2 text-[10px] text-muted uppercase tracking-wide pb-1 font-medium">
              <span>Issue</span><span className="text-center">Your view</span><span className="text-right">Alignment</span>
            </div>
            {result.issues.map((issue) => (
              <div key={issue.label} className="grid grid-cols-3 gap-2 items-center py-1.5 border-b border-border/40 last:border-0">
                <span className="text-xs text-navy/70">{issue.label}</span>
                <div className="flex justify-center gap-0.5">
                  {[1,2,3,4,5].map((v) => (
                    <div key={v} className={`w-2.5 h-2.5 rounded-sm ${v <= issue.userVal ? 'bg-civic' : 'bg-soft-mid'}`} />
                  ))}
                </div>
                <div className="flex justify-end items-center gap-1">
                  {issue.aligned ? (
                    <span className="text-xs font-medium text-teal flex items-center gap-1">
                      <svg viewBox="0 0 12 12" fill="currentColor" className="w-3 h-3"><path fillRule="evenodd" clipRule="evenodd" d="M10.78 3.22a.75.75 0 010 1.06l-6 5.25a.75.75 0 01-1-.06L1.22 6.28a.75.75 0 011.06-1.06l2.22 2.22 5.22-4.5a.75.75 0 011.06.28z"/></svg>
                      Aligned
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-muted flex items-center gap-1">
                      <svg viewBox="0 0 12 12" fill="currentColor" className="w-3 h-3"><path d="M3.22 3.22a.75.75 0 011.06 0L6 4.94l1.72-1.72a.75.75 0 111.06 1.06L7.06 6l1.72 1.72a.75.75 0 11-1.06 1.06L6 7.06 4.28 8.78a.75.75 0 01-1.06-1.06L4.94 6 3.22 4.28a.75.75 0 010-1.06z"/></svg>
                      Differs
                    </span>
                  )}
                </div>
              </div>
            ))}

            {agreements.length > 0 && (
              <div className="pt-2 space-y-1">
                <p className="text-[10px] font-semibold text-muted uppercase tracking-wide">Major agreements</p>
                <div className="flex flex-wrap gap-1.5">
                  {agreements.map((a) => (
                    <span key={a.label} className="text-xs bg-teal-light text-teal px-2 py-0.5 rounded-full border border-teal/20">{a.label}</span>
                  ))}
                </div>
              </div>
            )}
            {disagreements.length > 0 && (
              <div className="pt-2 space-y-1">
                <p className="text-[10px] font-semibold text-muted uppercase tracking-wide">Major differences</p>
                <div className="flex flex-wrap gap-1.5">
                  {disagreements.map((a) => (
                    <span key={a.label} className="text-xs bg-soft text-muted px-2 py-0.5 rounded-full border border-border">{a.label}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── ResultsDashboardPage ─────────────────────────────────────────────────────

export default function ResultsDashboardPage() {
  const { navigate } = useNav()
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [showMethodology, setShowMethodology] = useState(false)

  const toggle = (id: string) => setExpanded((prev) => ({ ...prev, [id]: !prev[id] }))

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Header */}
      <div className="bg-navy">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
          <div className="flex items-center gap-2 text-xs text-blue-300/70 mb-4">
            <button onClick={() => navigate('home')} className="hover:text-white">Home</button>
            <span>/</span>
            <button onClick={() => navigate('quiz')} className="hover:text-white">Questionnaire</button>
            <span>/</span>
            <span className="text-white">Results</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 leading-tight" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
            Your alignment results
          </h1>
          <p className="text-blue-200/80 max-w-xl text-sm sm:text-base leading-relaxed">
            Based on your questionnaire answers and available candidate information for the <strong className="text-white">City Council — District 3</strong> race.
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Estimate disclaimer */}
        <Alert type="warning">
          <strong>These results are estimates.</strong> Match percentages are based on available evidence only and may be incomplete where candidate positions are uncertain, AI-interpreted, or not yet documented. The highest match is not an endorsement. Use these results alongside your own independent research. All data shown is placeholder.
        </Alert>

        <div className="mt-8 grid lg:grid-cols-[1fr_340px] gap-8">
          {/* Left column: match cards */}
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-navy text-lg" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                Candidate matches
              </h2>
              <PlaceholderBadge text="Placeholder percentages" />
            </div>

            {RESULTS.map((result, i) => (
              <MatchCard
                key={result.candidateId}
                result={result}
                rank={i + 1}
                expanded={!!expanded[result.candidateId]}
                onToggle={() => toggle(result.candidateId)}
              />
            ))}

            {/* Methodology panel */}
            <div className="bg-surface rounded-2xl border border-border overflow-hidden">
              <button
                onClick={() => setShowMethodology(!showMethodology)}
                className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-soft/50 transition-colors"
              >
                <span className="font-semibold text-navy text-sm" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                  How this was calculated
                </span>
                <svg viewBox="0 0 16 16" fill="currentColor" className={`w-4 h-4 text-muted transition-transform ${showMethodology ? 'rotate-180' : ''}`}>
                  <path fillRule="evenodd" clipRule="evenodd" d="M4.22 6.22a.75.75 0 011.06 0L8 8.94l2.72-2.72a.75.75 0 111.06 1.06l-3.25 3.25a.75.75 0 01-1.06 0L4.22 7.28a.75.75 0 010-1.06z"/>
                </svg>
              </button>
              {showMethodology && (
                <div className="px-5 pb-6 border-t border-border space-y-3 text-sm text-navy/70 leading-relaxed">
                  <p className="pt-4">Match percentages are calculated by comparing your questionnaire responses to available evidence about each candidate's policy positions. Each question is weighted by the importance level you selected (Low, Medium, or High).</p>
                  <p>Where a candidate's position is <EvidenceBadge type="ai-interpreted" size="xs" />, that comparison is given reduced weight. <EvidenceBadge type="unavailable" size="xs" /> positions are excluded entirely.</p>
                  <p>Questions you answered "Not Sure" or skipped are excluded from that candidate's calculation, which may affect the final percentage.</p>
                  <p>Match estimates are <strong>not predictions of future policy</strong> and do not account for positions not yet publicly documented.</p>
                  <button className="text-civic text-xs font-medium hover:text-civic-light underline">Read full methodology →</button>
                </div>
              )}
            </div>
          </div>

          {/* Right column: charts + actions */}
          <div className="space-y-6">
            {/* Radar */}
            <div className="bg-surface rounded-2xl border border-border p-5">
              <h3 className="font-semibold text-navy text-sm mb-1" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                Issue-by-issue alignment
              </h3>
              <p className="text-[10px] text-muted italic mb-4">Placeholder values — for visual reference only</p>
              <ResponsiveContainer width="100%" height={220}>
                <RadarChart data={RADAR_DATA} margin={{ top: 8, right: 16, bottom: 8, left: 16 }}>
                  <PolarGrid stroke="#dde3ed" />
                  <PolarAngleAxis dataKey="s" tick={{ fontSize: 9, fill: '#6b7a99' }} />
                  <Radar name="Jordan Reyes" dataKey="JR" stroke="#1a9e87" fill="#1a9e87" fillOpacity={0.2} />
                  <Radar name="Marcus Webb"  dataKey="MW" stroke="#2d5fa0" fill="#2d5fa0" fillOpacity={0.1} />
                  <Radar name="Patricia Chen"dataKey="PC" stroke="#c9922a" fill="#c9922a" fillOpacity={0.1} />
                  <RechartsTooltip contentStyle={{ fontSize: 11, borderRadius: 10, border: '1px solid #dde3ed' }} />
                </RadarChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-1 mt-3">
                {[
                  { name: 'Jordan Reyes',   color: '#1a9e87' },
                  { name: 'Marcus Webb',    color: '#2d5fa0' },
                  { name: 'Patricia Chen',  color: '#c9922a' },
                ].map((c) => (
                  <div key={c.name} className="flex items-center gap-2 text-xs text-muted">
                    <span className="w-4 h-1.5 rounded-sm shrink-0" style={{ backgroundColor: c.color }} />
                    {c.name}
                  </div>
                ))}
              </div>
            </div>

            {/* Compass */}
            <div className="bg-surface rounded-2xl border border-border p-5">
              <h3 className="font-semibold text-navy text-sm mb-1" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
                Governance compass
              </h3>
              <p className="text-[10px] text-muted mb-4">Your estimated position vs. candidates on two axes</p>
              <CompassChart />
              <p className="text-xs text-muted leading-relaxed mt-3">
                Compass positions are estimated from available evidence and are approximate. Axes reflect economic policy (left–right) and social governance approach (liberal–conservative) — not partisan affiliation.
              </p>
            </div>

            {/* Actions */}
            <div className="space-y-2.5">
              <button
                onClick={() => navigate('comparison')}
                className="w-full py-3 rounded-xl border border-civic text-civic text-sm font-semibold hover:bg-civic-pale transition-colors"
              >
                Compare candidates side by side
              </button>
              <button
                onClick={() => navigate('quiz')}
                className="w-full py-3 rounded-xl border border-border text-muted text-sm font-medium hover:text-navy hover:border-border-strong transition-colors"
              >
                Retake questionnaire
              </button>
              <button
                onClick={() => navigate('elections')}
                className="w-full py-3 rounded-xl bg-navy text-white text-sm font-semibold hover:bg-navy-mid transition-colors"
              >
                Back to all races
              </button>
            </div>

            {/* View sources */}
            <div className="text-center">
              <button
                onClick={() => navigate('candidate')}
                className="text-xs text-civic hover:text-civic-light underline transition-colors"
              >
                View sources for all positions →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
