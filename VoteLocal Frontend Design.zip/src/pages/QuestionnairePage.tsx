import { useState } from 'react'
import { useNav } from '../context/nav'
import { QUIZ_QUESTIONS } from '../data/placeholder'
import type { QuizAnswer } from '../types'

const AGREEMENT_OPTIONS = [
  { val: 1, label: 'Strongly Disagree', short: 'Strongly\nDisagree', color: 'red' },
  { val: 2, label: 'Disagree',          short: 'Disagree',           color: 'orange' },
  { val: 3, label: 'Neutral',           short: 'Neutral',            color: 'gray' },
  { val: 4, label: 'Agree',             short: 'Agree',              color: 'blue' },
  { val: 5, label: 'Strongly Agree',    short: 'Strongly\nAgree',    color: 'green' },
]

const IMPORTANCE_OPTS = [
  { val: 'low'    as const, label: 'Low',    desc: 'Not a top priority for me' },
  { val: 'medium' as const, label: 'Medium', desc: 'Somewhat important' },
  { val: 'high'   as const, label: 'High',   desc: 'Very important to me' },
]

// ─── Progress bar + category dots ────────────────────────────────────────────

function ProgressHeader({ step, total, answers }: { step: number; total: number; answers: Record<string, QuizAnswer> }) {
  const pct = Math.round(((step + 1) / total) * 100)
  const answeredCount = Object.values(answers).filter((a) => a.agreement !== undefined).length

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-navy">Question {step + 1} of {total}</span>
        <span className="text-xs text-muted font-mono">{answeredCount} answered · {pct}% complete</span>
      </div>
      <div className="relative h-2 bg-soft-mid rounded-full overflow-hidden">
        <div
          className="h-full bg-civic rounded-full transition-all duration-500 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Category dots */}
      <div className="flex items-center gap-1.5 flex-wrap">
        {QUIZ_QUESTIONS.map((q, i) => {
          const ans = answers[q.id]
          const isCurrent = i === step
          const isDone = ans !== undefined

          let dotClass = 'bg-soft-mid'
          if (isCurrent) dotClass = 'bg-civic w-5'
          else if (isDone) dotClass = 'bg-teal'

          return (
            <button
              key={i}
              onClick={() => {}} // navigate via parent state — intentionally no-op in this demo
              title={q.category}
              className={`h-2 rounded-full transition-all duration-200 ${dotClass}`}
              style={{ width: isCurrent ? '20px' : '8px' }}
            />
          )
        })}
      </div>
    </div>
  )
}

// ─── Category badge ───────────────────────────────────────────────────────────

function CategoryBadge({ label }: { label: string }) {
  const colors: Record<string, string> = {
    'Housing & Development': 'bg-orange-50 text-orange-700 border-orange-200',
    'Public Safety':          'bg-red-50 text-red-700 border-red-200',
    'Local Taxes & Spending': 'bg-yellow-50 text-yellow-700 border-yellow-200',
    'Education':              'bg-green-50 text-green-700 border-green-200',
    'Transportation':         'bg-blue-50 text-blue-700 border-blue-200',
    'Environment':            'bg-teal-light text-teal border-teal/20',
    'Government Transparency':'bg-purple-50 text-purple-700 border-purple-200',
  }
  return (
    <span className={`inline-flex items-center text-[10px] font-mono font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${colors[label] ?? 'bg-civic-pale text-civic border-civic/20'}`}>
      {label}
    </span>
  )
}

// ─── Submission screen ────────────────────────────────────────────────────────

function SubmissionScreen({ answerCount, total, onRetake }: { answerCount: number; total: number; onRetake: () => void }) {
  const { navigate } = useNav()
  return (
    <div className="min-h-screen bg-soft flex items-center justify-center p-4 page-enter">
      <div className="max-w-md w-full">
        <div className="bg-surface rounded-2xl border border-border shadow-lg p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-teal-light border-2 border-teal flex items-center justify-center mx-auto mb-5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-8 h-8 text-teal">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/>
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-navy mb-2" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>
            Questionnaire complete
          </h2>
          <p className="text-muted text-sm mb-6 leading-relaxed">
            You answered <strong className="text-navy">{answerCount}</strong> of {total} questions.
            Unanswered questions are excluded from match calculations.
          </p>
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-700 text-left mb-6 leading-relaxed">
            <strong>About your results:</strong> Match percentages are estimates based on available evidence and may be incomplete where candidate positions are uncertain. Results are not endorsements.
          </div>
          <button
            onClick={() => navigate('results')}
            className="w-full py-3 rounded-xl bg-civic text-white font-semibold hover:bg-civic-hover transition-colors mb-2.5"
          >
            View my alignment results →
          </button>
          <button
            onClick={onRetake}
            className="w-full py-3 rounded-xl border border-border text-muted text-sm hover:text-navy hover:border-navy transition-colors"
          >
            Retake from beginning
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── QuestionnairePage ────────────────────────────────────────────────────────

export default function QuestionnairePage() {
  const { navigate } = useNav()
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, QuizAnswer>>({})
  const [showWhy, setShowWhy] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [saveFlash, setSaveFlash] = useState(false)

  const q = QUIZ_QUESTIONS[step]
  const ans = answers[q.id]
  const total = QUIZ_QUESTIONS.length

  const setAgreement = (val: number | null) => {
    setAnswers((prev) => ({
      ...prev,
      [q.id]: { questionId: q.id, agreement: val, importance: prev[q.id]?.importance ?? 'medium' },
    }))
  }

  const setImportance = (val: 'low' | 'medium' | 'high') => {
    setAnswers((prev) => ({
      ...prev,
      [q.id]: { questionId: q.id, agreement: prev[q.id]?.agreement ?? null, importance: val },
    }))
  }

  const handleSave = () => {
    setSaveFlash(true)
    setTimeout(() => setSaveFlash(false), 2000)
  }

  const handleNext = () => {
    if (step < total - 1) { setStep(step + 1); setShowWhy(false) }
    else setSubmitted(true)
  }

  const handlePrev = () => {
    if (step > 0) { setStep(step - 1); setShowWhy(false) }
  }

  const jumpTo = (i: number) => { setStep(i); setShowWhy(false) }

  if (submitted) {
    return (
      <SubmissionScreen
        answerCount={Object.keys(answers).length}
        total={total}
        onRetake={() => { setStep(0); setSubmitted(false); setAnswers({}) }}
      />
    )
  }

  const isAnswered = ans?.agreement !== undefined || ans?.agreement === null
  const importanceVal = ans?.importance ?? 'medium'

  return (
    <div className="min-h-screen bg-soft page-enter">
      {/* Header */}
      <div className="bg-surface border-b border-border sticky top-[60px] z-40">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-xs text-muted">
              <button onClick={() => navigate('home')} className="hover:text-civic">Home</button>
              <span>/</span>
              <span className="text-navy font-medium">Questionnaire</span>
            </div>
            <button
              onClick={handleSave}
              className={`flex items-center gap-1.5 text-xs font-medium transition-colors px-3 py-1.5 rounded-lg border
                ${saveFlash
                  ? 'text-teal bg-teal-light border-teal/30'
                  : 'text-muted border-border hover:text-navy hover:border-border-strong'
                }`}
            >
              {saveFlash ? (
                <><svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5"><path fillRule="evenodd" clipRule="evenodd" d="M12.78 3.22a.75.75 0 010 1.06l-6.5 6.5a.75.75 0 01-1.06 0l-2.5-2.5a.75.75 0 111.06-1.06L5.75 9.19l5.97-5.97a.75.75 0 011.06 0z"/></svg>Saved</>
              ) : (
                <><svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5"><path d="M2 2a1 1 0 011-1h7l3 3v8a1 1 0 01-1 1H3a1 1 0 01-1-1V2zm5 7a1.5 1.5 0 100 3 1.5 1.5 0 000-3zM5 3.5a.5.5 0 000 1h4a.5.5 0 000-1H5z"/></svg>Save progress</>
              )}
            </button>
          </div>
          <ProgressHeader step={step} total={total} answers={answers} />
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        {/* Placeholder notice */}
        <div className="mb-5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-xs font-medium">
          <svg viewBox="0 0 14 14" fill="currentColor" className="w-3.5 h-3.5 text-amber-500">
            <path fillRule="evenodd" clipRule="evenodd" d="M7 1a6 6 0 100 12A6 6 0 007 1zm-.75 3.25a.75.75 0 011.5 0v3a.75.75 0 01-1.5 0v-3zm.75 5.5a.75.75 0 100-1.5.75.75 0 000 1.5z"/>
          </svg>
          Placeholder questionnaire — fictional questions for design demonstration
        </div>

        {/* Main card */}
        <div className="bg-surface rounded-2xl border border-border shadow-sm overflow-hidden">
          {/* Category */}
          <div className="px-6 sm:px-8 pt-7 pb-5">
            <CategoryBadge label={q.category} />

            <p
              className="mt-5 text-xl sm:text-2xl font-semibold text-navy leading-snug"
              style={{ fontFamily: 'Fraunces, Georgia, serif' }}
            >
              "{q.statement}"
            </p>

            {/* Why it matters */}
            <button
              onClick={() => setShowWhy(!showWhy)}
              className="mt-4 flex items-center gap-1.5 text-xs text-civic font-medium hover:text-civic-light transition-colors"
            >
              <svg viewBox="0 0 14 14" fill="currentColor" className={`w-3.5 h-3.5 transition-transform ${showWhy ? 'rotate-90' : ''}`}>
                <path fillRule="evenodd" clipRule="evenodd" d="M4.22 5.22a.5.5 0 01.7 0L7 7.3l2.08-2.08a.5.5 0 01.7.7L7.35 8.35a.5.5 0 01-.7 0L4.22 5.92a.5.5 0 010-.7z"/>
              </svg>
              Why this matters locally
            </button>

            {showWhy && (
              <div className="mt-3 p-4 rounded-xl bg-civic-pale border border-civic/20 text-sm text-navy/70 leading-relaxed">
                {q.whyItMatters}
              </div>
            )}
          </div>

          {/* Agreement scale */}
          <div className="px-6 sm:px-8 pb-5">
            <p className="text-xs font-medium text-muted-light uppercase tracking-widest mb-4">
              How much do you agree?
            </p>

            {/* 5-point scale — desktop horizontal */}
            <div className="hidden sm:flex gap-2">
              {AGREEMENT_OPTIONS.map(({ val, label }) => {
                const selected = ans?.agreement === val
                return (
                  <button
                    key={val}
                    onClick={() => setAgreement(val)}
                    className={`flex-1 py-4 rounded-xl border text-center text-[11px] font-semibold transition-all duration-150 leading-tight
                      ${selected
                        ? 'bg-civic text-white border-civic shadow-sm shadow-civic/20 scale-[1.03]'
                        : 'bg-surface border-border text-navy/60 hover:border-civic/40 hover:text-civic hover:bg-civic-pale'
                      }`}
                  >
                    <span className="block text-xl font-bold mb-1 font-mono" style={{ fontFamily: 'DM Mono, monospace' }}>{val}</span>
                    {label.replace('\n', ' ')}
                  </button>
                )
              })}
            </div>

            {/* Mobile: stacked */}
            <div className="sm:hidden flex flex-col gap-2">
              {AGREEMENT_OPTIONS.map(({ val, label }) => {
                const selected = ans?.agreement === val
                return (
                  <button
                    key={val}
                    onClick={() => setAgreement(val)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-medium transition-all
                      ${selected ? 'bg-civic text-white border-civic' : 'bg-surface border-border text-navy/70 hover:border-civic hover:bg-civic-pale'}`}
                  >
                    <span className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold font-mono shrink-0"
                      style={{ background: selected ? 'rgba(255,255,255,0.2)' : '#eef3fb', color: selected ? 'white' : '#2d5fa0' }}>
                      {val}
                    </span>
                    {label}
                  </button>
                )
              })}
            </div>

            {/* Not sure */}
            <button
              onClick={() => setAgreement(null)}
              className={`mt-2.5 w-full py-2.5 rounded-xl border text-sm font-medium transition-all
                ${ans?.agreement === null && isAnswered
                  ? 'bg-soft-mid border-border-strong text-muted'
                  : 'bg-surface border-border text-muted hover:border-border-strong hover:bg-soft'
                }`}
            >
              Not Sure / Skip this question
            </button>
          </div>

          {/* Importance selector */}
          <div className="px-6 sm:px-8 py-5 border-t border-border bg-soft/40">
            <p className="text-xs font-medium text-muted-light uppercase tracking-widest mb-3">
              How important is this issue to you?
            </p>
            <div className="flex gap-2.5">
              {IMPORTANCE_OPTS.map(({ val, label, desc }) => {
                const selected = importanceVal === val
                const activeStyles = {
                  high:   selected ? 'bg-gold-light border-gold text-gold-dark' : '',
                  medium: selected ? 'bg-civic-pale border-civic text-civic' : '',
                  low:    selected ? 'bg-soft-mid border-border-strong text-navy/60' : '',
                }
                return (
                  <button
                    key={val}
                    onClick={() => setImportance(val)}
                    title={desc}
                    className={`flex-1 py-3 rounded-xl border text-xs font-semibold capitalize transition-all
                      ${activeStyles[val] || 'bg-surface border-border text-muted hover:border-border-strong hover:bg-soft'}`}
                  >
                    {label}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Validation warning */}
          {step === total - 1 && !isAnswered && (
            <div className="mx-6 mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-2 text-xs text-amber-700">
              <svg viewBox="0 0 14 14" fill="currentColor" className="w-4 h-4 shrink-0 text-amber-500">
                <path fillRule="evenodd" clipRule="evenodd" d="M7.485 1.5c-.673-1.167-2.357-1.167-3.03 0L.175 10.667C-.498 11.833.345 13.25 1.69 13.25h10.62c1.346 0 2.188-1.417 1.515-2.583L7.485 1.5zM7 4.75a.75.75 0 01.75.75v2.5a.75.75 0 01-1.5 0v-2.5A.75.75 0 017 4.75zm0 6a.75.75 0 100-1.5.75.75 0 000 1.5z"/>
              </svg>
              You haven't answered this question. You can still submit — unanswered questions are excluded from match calculations.
            </div>
          )}

          {/* Navigation */}
          <div className="px-6 sm:px-8 py-5 border-t border-border flex items-center justify-between gap-4">
            <button
              onClick={handlePrev}
              disabled={step === 0}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-border text-sm font-medium text-muted hover:text-navy hover:border-border-strong transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            >
              ← Previous
            </button>

            {/* Jump dots */}
            <div className="hidden sm:flex items-center gap-1 overflow-hidden max-w-[120px]">
              {QUIZ_QUESTIONS.map((_, i) => {
                const isDone = answers[QUIZ_QUESTIONS[i].id] !== undefined
                const isCurr = i === step
                return (
                  <button
                    key={i}
                    onClick={() => jumpTo(i)}
                    className={`transition-all rounded-full shrink-0 ${
                      isCurr ? 'w-5 h-2 bg-civic' : isDone ? 'w-2 h-2 bg-teal' : 'w-2 h-2 bg-soft-mid hover:bg-border-strong'
                    }`}
                    title={`Question ${i + 1}`}
                  />
                )
              })}
            </div>

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-civic text-white text-sm font-semibold hover:bg-civic-hover transition-all shadow-sm"
            >
              {step < total - 1 ? 'Next →' : 'View Results →'}
            </button>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted">
          {Object.keys(answers).length} of {total} answered
          <span className="mx-2">·</span>
          <button onClick={handleSave} className="text-civic hover:text-civic-light underline">Save and continue later</button>
        </p>
      </div>
    </div>
  )
}
