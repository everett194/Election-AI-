export type PageName =
  | 'home'
  | 'elections'
  | 'race'
  | 'candidate'
  | 'comparison'
  | 'quiz'
  | 'results'

export type EvidenceType =
  | 'verified-fact'
  | 'candidate-provided'
  | 'public-statement'
  | 'voting-record'
  | 'third-party'
  | 'ai-interpreted'
  | 'unclear'
  | 'unavailable'

export interface Source {
  title: string
  outlet: string
  date: string
  url: string
  type: EvidenceType
}

export interface PolicyPosition {
  issue: string
  summary: string
  detail: string
  scale: number // 1–5
  evidenceType: EvidenceType
  sources: Source[]
}

export interface Candidate {
  id: string
  name: string
  party: string | null
  occupation: string
  bio: string
  photoPlaceholder: string // initials for avatar
  issues: string[]
  confidence: number // 1–5
  experience: string[]
  positions: PolicyPosition[]
  endorsements: string[]
  finance: { raised: string; spent: string; topDonors: string[] }
  website: string
  lastUpdated: string
  sources: Source[]
}

export interface Race {
  id: string
  office: string
  jurisdiction: string
  electionDate: string
  candidateCount: number
  description: string
  candidateIds: string[]
}

export interface QuizQuestion {
  id: string
  category: string
  statement: string
  whyItMatters: string
}

export interface QuizAnswer {
  questionId: string
  agreement: number | null // 1–5 or null for Not Sure
  importance: 'low' | 'medium' | 'high'
}
