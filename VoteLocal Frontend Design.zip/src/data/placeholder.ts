/**
 * PLACEHOLDER DATA — For design demonstration only.
 * All candidate names, percentages, dates, sources, and policy positions
 * shown below are fictional samples intended to illustrate layout.
 * A developer connecting this frontend to the VoteLocal backend should
 * replace all values here with data from the API.
 */

import type { Candidate, Race, QuizQuestion } from '../types'

// ─── Candidates ────────────────────────────────────────────────────────────

export const CANDIDATES: Record<string, Candidate> = {
  'jordan-reyes': {
    id: 'jordan-reyes',
    name: 'Jordan Reyes',
    party: 'Democrat',
    occupation: 'Community Organizer',
    bio: 'Jordan Reyes has spent 12 years organizing tenant rights campaigns and neighborhood safety coalitions in District 3. A lifelong Riverside resident, Reyes founded the Eastside Housing Cooperative and served on the city\'s housing task force.',
    photoPlaceholder: 'JR',
    issues: ['Affordable Housing', 'Transit', 'Community Safety'],
    confidence: 4,
    experience: [
      'Executive Director, Eastside Housing Cooperative (2018–present)',
      'Member, City Housing Task Force (2020–2023)',
      'Neighborhood Safety Coalition Chair (2016–2018)',
    ],
    positions: [
      {
        issue: 'Housing & Development',
        summary: 'Supports mandatory affordable unit requirements in new developments',
        detail: 'Has publicly stated support for a 15% affordable unit requirement in all residential developments over 10 units. Backed the 2023 inclusionary zoning ballot measure.',
        scale: 4,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Candidate forum on housing policy', outlet: 'Riverside Press-Enterprise', date: '2025-03-12', url: '#', type: 'third-party' },
          { title: 'Reyes campaign housing platform', outlet: 'reyesfordistrict3.com', date: '2025-02-01', url: '#', type: 'candidate-provided' },
        ],
      },
      {
        issue: 'Public Safety',
        summary: 'Supports mental health co-responder program alongside policing',
        detail: 'Has advocated for a co-responder model pairing mental health workers with officers for non-violent calls, citing a pilot program in Sacramento as a model.',
        scale: 3,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Public safety candidate questionnaire', outlet: 'Riverside Police Officers Assoc.', date: '2025-04-02', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Local Taxes & Spending',
        summary: 'Favors targeted infrastructure levy, opposes broad tax increases',
        detail: 'Position inferred from candidate-provided budget priorities. Has not taken a public stance on the proposed 2026 general obligation bond.',
        scale: 3,
        evidenceType: 'ai-interpreted',
        sources: [
          { title: 'Campaign Q&A response', outlet: 'District 3 Neighborhood Council', date: '2025-04-18', url: '#', type: 'candidate-provided' },
        ],
      },
      {
        issue: 'Transportation',
        summary: 'Strongly supports expanded bus rapid transit and protected bike lanes',
        detail: 'Endorsed the Transit First Riverside coalition\'s platform and has called for converting one car lane on Magnolia Ave to a protected bus lane.',
        scale: 5,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Transit First Riverside endorsement statement', outlet: 'Transit First Riverside', date: '2025-02-20', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Environment',
        summary: 'Supports binding 2030 emissions targets for municipal operations',
        detail: 'Signed the Climate Cities Pledge and has written op-eds calling for the city to adopt a net-zero operations goal by 2030.',
        scale: 4,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Climate Cities Pledge signatory list', outlet: 'Climate Cities Network', date: '2025-01-15', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Government Transparency',
        summary: 'Position not yet publicly stated',
        detail: 'No public statements or questionnaire responses found on government transparency issues as of last data update.',
        scale: 3,
        evidenceType: 'unavailable',
        sources: [],
      },
    ],
    endorsements: ['Riverside Teachers Union', 'Sierra Club — Inland Empire Chapter', 'Downtown Riverside Business Alliance'],
    finance: { raised: '$84,200', spent: '$61,450', topDonors: ['Riverside Tenants Coalition PAC', 'SEIU Local 721', 'Eastside Neighborhood Fund'] },
    website: 'reyesfordistrict3.com',
    lastUpdated: '2025-05-01',
    sources: [
      { title: 'Candidate financial disclosure', outlet: 'Riverside City Clerk', date: '2025-04-30', url: '#', type: 'verified-fact' },
      { title: 'Voter guide biography', outlet: 'Riverside County Elections', date: '2025-03-01', url: '#', type: 'candidate-provided' },
    ],
  },

  'patricia-chen': {
    id: 'patricia-chen',
    name: 'Patricia Chen',
    party: 'Republican',
    occupation: 'Small Business Owner',
    bio: 'Patricia Chen has operated a family-owned hardware supply business in District 3 for 18 years. She serves on the Riverside Chamber of Commerce board and has been a consistent advocate for reducing regulatory burden on local businesses.',
    photoPlaceholder: 'PC',
    issues: ['Small Business', 'Fiscal Responsibility', 'Neighborhood Safety'],
    confidence: 3,
    experience: [
      'Owner, Chen Hardware Supply Co. (2007–present)',
      'Board Member, Riverside Chamber of Commerce (2019–present)',
      'District 3 Planning Advisory Committee (2021–2023)',
    ],
    positions: [
      {
        issue: 'Housing & Development',
        summary: 'Prefers market-driven housing solutions over mandated affordability requirements',
        detail: 'Has publicly stated opposition to inclusionary zoning mandates, arguing they reduce overall housing supply. Supports by-right permitting streamlining.',
        scale: 2,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Chamber of Commerce housing panel', outlet: 'Riverside Chamber of Commerce', date: '2025-02-28', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Public Safety',
        summary: 'Supports maintaining or increasing police department staffing levels',
        detail: 'Has called for adding 15 new officer positions and restoring the community policing unit that was reduced in the 2024 budget.',
        scale: 4,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Candidate survey — public safety', outlet: 'Riverside Police Officers Assoc.', date: '2025-04-02', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Local Taxes & Spending',
        summary: 'Opposes tax increases; supports spending review and efficiency audits',
        detail: 'Has pledged to vote against any new tax measures without a corresponding independent efficiency audit of current city spending.',
        scale: 1,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Chen campaign platform — fiscal policy', outlet: 'patriciachen2025.com', date: '2025-02-15', url: '#', type: 'candidate-provided' },
        ],
      },
      {
        issue: 'Transportation',
        summary: 'Prioritizes parking and road maintenance over transit expansion',
        detail: 'Has opposed proposals to reduce parking minimums and expressed concern that bus lane conversions would harm businesses that rely on customer parking.',
        scale: 2,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Business district transportation forum', outlet: 'Riverside Business Improvement District', date: '2025-03-18', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Environment',
        summary: 'Supports voluntary business sustainability programs; opposes binding mandates',
        detail: 'Position inferred from general statements about regulatory burden. No direct statements on municipal climate targets found.',
        scale: 2,
        evidenceType: 'ai-interpreted',
        sources: [
          { title: 'Chamber environmental working group notes', outlet: 'Riverside Chamber of Commerce', date: '2024-11-10', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Government Transparency',
        summary: 'Supports public contract posting; has called for auditor-general position',
        detail: 'Has proposed creating an independent city auditor position and requiring contracts above $25,000 to be posted publicly with 10-day comment periods.',
        scale: 4,
        evidenceType: 'candidate-provided',
        sources: [
          { title: 'Chen platform — government accountability', outlet: 'patriciachen2025.com', date: '2025-02-15', url: '#', type: 'candidate-provided' },
        ],
      },
    ],
    endorsements: ['Riverside Police Officers Association', 'Riverside County Republican Party', 'Inland Empire Contractors Association'],
    finance: { raised: '$112,800', spent: '$89,300', topDonors: ['Inland Empire Business PAC', 'Riverside Contractors Coalition', 'Personal campaign funds'] },
    website: 'patriciachen2025.com',
    lastUpdated: '2025-05-01',
    sources: [
      { title: 'Candidate financial disclosure', outlet: 'Riverside City Clerk', date: '2025-04-30', url: '#', type: 'verified-fact' },
      { title: 'Voter guide biography', outlet: 'Riverside County Elections', date: '2025-03-01', url: '#', type: 'candidate-provided' },
    ],
  },

  'marcus-webb': {
    id: 'marcus-webb',
    name: 'Marcus Webb',
    party: null,
    occupation: 'Former City Planner',
    bio: 'Marcus Webb spent 20 years as a senior planner with the City of Riverside before retiring in 2022. He now teaches urban planning at UC Riverside Extension and consults for nonprofit community development organizations.',
    photoPlaceholder: 'MW',
    issues: ['Urban Planning', 'Infrastructure', 'Fiscal Accountability'],
    confidence: 4,
    experience: [
      'Senior City Planner, City of Riverside (2002–2022)',
      'Adjunct Faculty, UC Riverside Extension (2022–present)',
      'Board Member, Inland Communities Foundation (2023–present)',
    ],
    positions: [
      {
        issue: 'Housing & Development',
        summary: 'Supports evidence-based zoning reform; cautious on inclusionary mandates',
        detail: 'Advocates for updating the general plan\'s housing element with data-driven density targets. Has expressed concern that inclusionary mandates alone are insufficient without parallel infrastructure investment.',
        scale: 3,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Urban planning lecture — housing policy transcript', outlet: 'UC Riverside Extension', date: '2025-01-22', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Public Safety',
        summary: 'Supports comprehensive community safety strategy beyond policing',
        detail: 'Has published opinion pieces arguing that long-term safety outcomes depend on environmental design, youth programming, and economic opportunity as much as enforcement.',
        scale: 3,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Op-ed: "Rethinking District 3 Safety"', outlet: 'Riverside Press-Enterprise', date: '2025-02-10', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Local Taxes & Spending',
        summary: 'Supports infrastructure bond if tied to specific project accountability',
        detail: 'Has called for an infrastructure bond measure with independent project oversight board and quarterly public reporting on milestones.',
        scale: 3,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Webb campaign platform', outlet: 'marcuswebb4council.com', date: '2025-03-01', url: '#', type: 'candidate-provided' },
        ],
      },
      {
        issue: 'Transportation',
        summary: 'Strong supporter of multi-modal transit investment',
        detail: 'Led the 2019 transit corridor study during his tenure with the city. Has endorsed the RTA Bus Rapid Transit expansion proposal.',
        scale: 4,
        evidenceType: 'voting-record',
        sources: [
          { title: '2019 Transit Corridor Planning Study', outlet: 'City of Riverside Planning Dept.', date: '2019-09-15', url: '#', type: 'verified-fact' },
        ],
      },
      {
        issue: 'Environment',
        summary: 'Supports climate adaptation planning integrated into general plan',
        detail: 'Has written that climate resilience must be embedded in land use planning. Supports the 2030 emissions targets as a floor, not a ceiling.',
        scale: 4,
        evidenceType: 'public-statement',
        sources: [
          { title: 'Op-ed: "Planning for Climate in the Inland Empire"', outlet: 'Cal Cities Policy Brief', date: '2024-10-05', url: '#', type: 'third-party' },
        ],
      },
      {
        issue: 'Government Transparency',
        summary: 'Strongly supports open government; has specific policy proposals',
        detail: 'Advocates for real-time city budget dashboards, mandatory conflict-of-interest disclosures for planning commission members, and livestreamed council meetings with searchable transcripts.',
        scale: 5,
        evidenceType: 'candidate-provided',
        sources: [
          { title: 'Webb transparency policy white paper', outlet: 'marcuswebb4council.com', date: '2025-03-01', url: '#', type: 'candidate-provided' },
        ],
      },
    ],
    endorsements: ['Riverside Neighborhood Councils Coalition', 'UC Riverside Faculty Senate', 'Inland Communities Foundation'],
    finance: { raised: '$47,600', spent: '$38,900', topDonors: ['Individual donors under $500 (largest share)', 'Inland Communities Foundation PAC', 'Academic community donors'] },
    website: 'marcuswebb4council.com',
    lastUpdated: '2025-05-01',
    sources: [
      { title: 'Candidate financial disclosure', outlet: 'Riverside City Clerk', date: '2025-04-30', url: '#', type: 'verified-fact' },
      { title: 'Voter guide biography', outlet: 'Riverside County Elections', date: '2025-03-01', url: '#', type: 'candidate-provided' },
    ],
  },
}

// ─── Races ─────────────────────────────────────────────────────────────────

export const RACES: Race[] = [
  {
    id: 'city-council-d3',
    office: 'City Council — District 3',
    jurisdiction: 'City of Riverside',
    electionDate: 'November 4, 2025',
    candidateCount: 3,
    description: 'The City Council represents residents in municipal governance, sets local policy, and approves the city budget. District 3 covers the Eastside and University neighborhoods.',
    candidateIds: ['jordan-reyes', 'patricia-chen', 'marcus-webb'],
  },
  {
    id: 'school-board-7',
    office: 'School Board — Seat 7',
    jurisdiction: 'Riverside Unified School District',
    electionDate: 'November 4, 2025',
    candidateCount: 2,
    description: 'The School Board governs Riverside Unified, setting education policy for approximately 42,000 students across 56 schools. Seat 7 represents the western portion of the district.',
    candidateIds: ['jordan-reyes', 'patricia-chen'],
  },
  {
    id: 'county-assessor',
    office: 'County Assessor',
    jurisdiction: 'Riverside County',
    electionDate: 'November 4, 2025',
    candidateCount: 2,
    description: 'The County Assessor determines the value of all taxable property in Riverside County for purposes of calculating property tax. The office directly affects homeowner tax bills.',
    candidateIds: ['patricia-chen', 'marcus-webb'],
  },
]

// ─── Quiz Questions ─────────────────────────────────────────────────────────

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // Housing
  {
    id: 'h1',
    category: 'Housing & Development',
    statement: 'Developers should be required to include affordable units in all new residential buildings with 10 or more units.',
    whyItMatters: 'Inclusionary zoning is a common tool local governments use to ensure new housing includes below-market units for lower-income residents. In Riverside, the share of cost-burdened renters (spending more than 30% of income on housing) has grown to 47%.',
  },
  {
    id: 'h2',
    category: 'Housing & Development',
    statement: 'Vacant lots near transit corridors should be rezoned to allow higher-density housing, even if it changes neighborhood character.',
    whyItMatters: 'Transit-oriented development is widely supported by urban planners as a way to reduce car dependency and increase housing supply near job centers. Local debates often center on concerns about neighborhood scale and displacement.',
  },
  {
    id: 'h3',
    category: 'Housing & Development',
    statement: 'The city should partner with nonprofit developers to build workforce housing for teachers, nurses, and other essential workers.',
    whyItMatters: 'Riverside has struggled to retain essential workers who cannot afford to live near where they work. Nonprofit housing development is one tool; others include employer partnerships and subsidized lending programs.',
  },
  // Public Safety
  {
    id: 's1',
    category: 'Public Safety',
    statement: 'The police department\'s budget should be maintained or increased to address public safety concerns in the district.',
    whyItMatters: 'Riverside\'s police staffing ratio is below the national average for cities of comparable size. Some residents cite response time concerns; others argue that reallocation to social services would address root causes more effectively.',
  },
  {
    id: 's2',
    category: 'Public Safety',
    statement: 'Mental health professionals should be dispatched alongside police officers to respond to non-violent mental health crises.',
    whyItMatters: 'Co-responder programs have reduced arrests and hospital admissions in cities including Denver, Sacramento, and Eugene. They require upfront investment in hiring and training but may reduce long-term costs.',
  },
  // Taxes
  {
    id: 't1',
    category: 'Local Taxes & Spending',
    statement: 'The city should raise property taxes if necessary to fund road and infrastructure repairs.',
    whyItMatters: 'Riverside\'s infrastructure backlog is estimated at $340 million. The city has deferred maintenance on roads, parks, and water systems. A general obligation bond or parcel tax would require voter approval.',
  },
  {
    id: 't2',
    category: 'Local Taxes & Spending',
    statement: 'Local businesses in underserved neighborhoods should receive tax incentives to encourage investment and job creation.',
    whyItMatters: 'Enterprise zone-style incentives have mixed evidence nationally. Supporters argue they spur local employment; critics note that benefits sometimes go to businesses that would have located there anyway.',
  },
  // Education
  {
    id: 'e1',
    category: 'Education',
    statement: 'The school district should protect and expand arts, music, and physical education programs, even if it requires reallocation of other funds.',
    whyItMatters: 'Research links arts and physical education to improved attendance, graduation rates, and student wellbeing. RUSD reduced these programs during budget cuts in 2023; restoring them would cost approximately $8M annually.',
  },
  {
    id: 'e2',
    category: 'Education',
    statement: 'Schools should be required to publish detailed, plain-language reports on how every dollar is spent, accessible online.',
    whyItMatters: 'California requires basic fiscal transparency from school districts, but the depth and accessibility of published data varies significantly. Enhanced transparency can build community trust and improve oversight.',
  },
  // Transportation
  {
    id: 'tr1',
    category: 'Transportation',
    statement: 'The city should create dedicated bus rapid transit lanes on major corridors, even if it reduces available vehicle lanes.',
    whyItMatters: 'Dedicated bus lanes dramatically improve transit reliability and ridership but can reduce road capacity for cars. The trade-off is a central debate in urban mobility policy.',
  },
  {
    id: 'tr2',
    category: 'Transportation',
    statement: 'The city should prioritize installing electric vehicle charging infrastructure in its capital improvement budget.',
    whyItMatters: 'EV adoption in Riverside is growing but public charging infrastructure is unevenly distributed. Prioritizing EV charging could support lower-income residents who cannot charge at home, but competes with other infrastructure needs.',
  },
  // Environment
  {
    id: 'env1',
    category: 'Environment',
    statement: 'The city should adopt binding targets to reduce municipal greenhouse gas emissions by at least 50% by 2030.',
    whyItMatters: 'Riverside\'s Climate Action Plan contains voluntary goals but no enforcement mechanism. Several California cities have adopted binding targets. Achieving them typically requires electrification of city fleet vehicles and facilities.',
  },
  {
    id: 'env2',
    category: 'Environment',
    statement: 'New industrial facilities near residential areas should require environmental impact assessments with mandatory community input periods.',
    whyItMatters: 'District 3 includes several industrial-residential boundary areas. Communities with disproportionate pollution burden have historically had limited input on siting decisions. Enhanced review adds time and cost to approvals.',
  },
  // Transparency
  {
    id: 'gov1',
    category: 'Government Transparency',
    statement: 'All city council meetings should be livestreamed and archived with searchable transcripts, at public expense.',
    whyItMatters: 'Many jurisdictions have adopted this practice. Riverside currently livestreams council meetings but does not provide searchable transcripts. The estimated cost of a transcription service is $40,000–$80,000 annually.',
  },
  {
    id: 'gov2',
    category: 'Government Transparency',
    statement: 'All city contracts above $50,000 should be posted publicly before final approval, with a 7-day comment period.',
    whyItMatters: 'Pre-approval contract disclosure is a best practice in government transparency. It allows community scrutiny of how public money is spent and can deter conflicts of interest, though it also adds time to procurement.',
  },
]
